***********Para el inciciso 1 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_1.sql
\i /home/jose/Escritorio/PRACTICA_201505550/PRESENTACION/PROPIEDADES.sql

***********Para el inciciso 2 *********************************************

\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_2.sql

\d+ EVENTO

***********Para el inciciso 3 *********************************************

\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_3.sql
\d+ EVENTO
--PRUEBA
INSERT INTO EVENTO VALUES(1,'catar',1,2,3,'2008/7/24 11:00:00');



***********Para el inciciso 4 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_4.sql
\d+ SEDE
\d+ EVENTO

***********Para el inciciso 5 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_5.sql
\d+ MIEMBRO

***********Para el inciciso 6 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_6.sql

\i /home/jose/Escritorio/PRACTICA_201505550/PRESENTACION/MOSTRAR.sql

***********Para el inciciso 7 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_7.sql

\d+ PAIS
\d+ TIPO_MEDALLA
\d+ DEPARTAMENTO

***********Para el inciciso 8 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_8.sql

\d+ ATLETA
\d+ DISCIPLINA_ATLETA

***********Para el inciciso 9 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_9.sql
\d+ COSTO_EVENTO

***********Para el inciciso 10 *********************************************
SELECT * FROM TIPO_MEDALLA;
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_10.sql
SELECT * FROM TIPO_MEDALLA;

***********Para el inciciso 11 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_11.sql
--SELECT * FROM TELEVISORA;
--SELECT * FROM COSTO EVENTO;

***********Para el inciciso 12 *********************************************
SELECT * FROM DISCIPLINA;
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_12.sql
SELECT * FROM DISCIPLINA;

***********Para el inciciso 13 *********************************************
SELECT * FROM DISCIPLINA;
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_13.sql
SELECT * FROM DISCIPLINA;

***********Para el inciciso 14 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_14.sql
\d+ ATLETA

***********Para el inciciso 15 *********************************************
\i /home/jose/Escritorio/PRACTICA_201505550/SCRIPTS/INCISO_15.sql
\d+ ATLETA
--PRUEBA
INSERT INTO ATLETA VALUES(1,'JOSE','HERNANDEZ',26,'CATAR',2,3,NULL);
