\d+ profesion;
\d+ pais;
\d+ puesto;
\d+ departamento;
\d+ miembro;
\d+ puesto_miembro;
\d+ tipo_medalla;
\d+ medallero;
\d+ disciplina;
\d+ atleta;
\d+ categoria;
\d+ tipo_participacion;
\d+ evento;
\d+ evento_atleta;
\d+ televisora;
\d+ costo_evento;

--\d+ sede;
--\d+ disciplina_atleta;

