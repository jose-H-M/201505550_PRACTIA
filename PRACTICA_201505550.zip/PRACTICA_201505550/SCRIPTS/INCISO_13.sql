--ACTUALIZAR NUMERO DE TELEFONO
UPDATE MIEMBRO SET telefono=55464601 WHERE CONCAT(nombre,' ',apellido)='Laura Cunha Silva';
UPDATE MIEMBRO SET telefono=91514243 WHERE CONCAT(nombre,' ',apellido)='Jeuel Villalpando';
UPDATE MIEMBRO SET telefono=920686670 WHERE CONCAT(nombre,' ',apellido)='Scott Mitchell';
